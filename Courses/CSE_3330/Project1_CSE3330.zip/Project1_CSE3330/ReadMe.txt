PROJECT_1 - CSE_3330

GROUP_MEMBER: CHERRYL MARIA BIBIN, NINAD PANDIT, GIA DAO

Given the following requirements for a simple database for the National Hockey League (NHL):
+	The NHL has many teams
+	Each team has a name, a city, a coach, a captain, and a set of players 
+	Each player belongs to only one team
+	Each player has a name, a position (such as left wing or goalie), a salary, a skill level, and a set of injury records
+	A team captain is also a player
+	A game is played between two teams (referred to as host_team and guest_team) and has a date (such as May 11th, 2017) and a score (such as 4 to 2).

PART 1: ER DIAGRAM

Tool used:
 
+	Creately

PART 2: SQL QUERIES

Tool used:

+	Sublime Text: Edit Source Code for Select and Create Table Statement

+	Filezilla: Transfering files

+	SQLite3: Compile the .sql file


