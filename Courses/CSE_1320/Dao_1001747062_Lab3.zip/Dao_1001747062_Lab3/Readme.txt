Running the program:
- The console will show up: "Please indicate number of records you want to enter (min 5, max 15): "
The user will have to put the exact number lies between 5 and 15, otherwise the user will be asked to enter again with a new number.
For each first name and last name, it can only contain maximum of 20 characters, otherwise the program will crash.
- If the user enter 1: The program will print out the records.

- If the user enter 2: The program will search for the first name of the student that the user typed in (Remember: the searched name has to be exactly matched the first name enter, or it will print out no first name match)

- If the user enter 3: The program will search for the last name of the student that the user typed in (Remember: the searched name has to be exactly matched the last name enter, or it will print out no last name match)

- If the user typed in 4: The program will sort the records of students due to their scores.
- If the user typed in 5: sort the records of students according to their names alphabetically, andthen print the sorted records. 

- If the user typed in 6: The program prints record of the student with the maximum score. If there are multiplestudents with the same maximum score, print records for all of them. 

- If the user typed in 7: The program prints record of the student with the minimum score. If there are multiplestudents with the same minimum score, print records for all of them. 

- If the user typed in 0: Exit the program – terminate on a specific input from the user. Let that specific input be aninteger of value 0. 

- If the user enter a number that different than those optional numbers listed, the program will ask the user to re-enter a number again.