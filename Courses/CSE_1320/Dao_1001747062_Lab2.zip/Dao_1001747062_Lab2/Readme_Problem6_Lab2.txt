From Line 9 to Line 17:
- Set up a recursive function.
- Calculating element at xth position in the sequence
equals to (x - 1)th ^ 2 - 1
- Define the first element in the sequence is 1.
- The number at position x will equal to 1 plus square of number at position x - 1.

From Line 20 to Line 24:
- Ask the user to enter number at position x and print out the first x terms of that sequence.