From Line 8 to Line 12:
- Ask the user to enter an array of characters
- Each element has to have size of 4.

From Line 14 to Line 25:
- Using bubble sort to sort the array of characters.
- Use strcpy() to swap the position of string.