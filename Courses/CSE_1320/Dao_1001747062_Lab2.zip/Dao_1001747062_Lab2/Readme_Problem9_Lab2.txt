From Line 6 to Line 8:
- Ask the user to enter a string

From Line 13 to Line 21:
- For this problem, we'll be using strtok, to separate the word using pointer once it finds the string contains special characters.
- Pointer word mark the memory address of the special character found and place in that position a NULL character. (Line 13 and Line 21).
- Using while loop to keep cutting the string into smaller string.
- Once it's marked, continue with the remaining string.