From Line 68 to Line 79:
- Ask the user to enter hours of playing in array A and hours of studying in array B.
- The array only contain 6 elements represent 6 days.

From Line 4 to Line 15:
- Both arrays have to be sorted in increasing order.

From Line 57 to Line 63:
- Set up the Mean function that calculate the average hours of playing and hours
of studying of the person in 6 days.

From Line 49 to Line 54:
- Return the median equals to the sum of 2 middle numbers divided by 2.

From Line 28 to Line 46:
- Count the occurence of hours of playing in array A and hours of studying in array B each day.
- After finish counting the number of appearance (Line 35), compare the total count in each array with variable max
- max by then is the mode value in each array, which is assigned to x[i] (Line 43).
- return the mode for both arrays. 