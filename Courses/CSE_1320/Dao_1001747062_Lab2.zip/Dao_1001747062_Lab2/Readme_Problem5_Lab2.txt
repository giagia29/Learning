Line 8 and Line 9:
- Ask the user to enter the string from the keyboard.

From Line 15 to Line 18:
- We can reverse the string by printing backwards, starting from the final position.
