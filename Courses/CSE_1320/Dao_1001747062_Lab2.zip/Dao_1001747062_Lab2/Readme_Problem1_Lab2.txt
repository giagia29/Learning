From Line 5 to Line 16:
- You have to ask the user to enter the total characters
of both arrays and ask the user to specify each elements
in both arrays.
- Remember: Array A has to be large enough to hold array B.

Line 17 and Line 23:
- Adding array B to array A, then have to start with the final position of array A and add whole array B starting from that position: Mark i as x (x is the final position of array A).

From Line 35 to Line 37: 
- After copying the first element in array B into the final position in array A, increment the index to move to the blank position to continue copying the value.

From Line 40 to 51: 
- Sorting the new array A after it has done adding using bubble sort.
- Then print out the new array A after it has merged with array B.