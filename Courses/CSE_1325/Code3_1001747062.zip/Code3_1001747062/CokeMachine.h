//Name: Gia Dao, Student ID: 1001747062
#include<iostream>
#include<string>

using namespace std;

class CokeMachine
{
    public:
        CokeMachine(std::string name, int cost, int change, int inventory)
        : machineName{name}, CokePrice{cost}, changeLevel{change}, inventoryLevel{inventory}
        {
        }

        std::string getMachineName()
        {
            return machineName;
        }

        bool buyACoke(int payment, std::string& change, int& action)
        {
            if (changeLevel < maxChangeCapacity)
            {
                if (payment < CokePrice)
                {
                    action = 3;
                    return false;
                }
                else if (payment - CokePrice > changeLevel)
                {
                    action = 2;
                    return false;
                }
                else if (payment == CokePrice)
                {
                    action = 4;
                    inventoryLevel = inventoryLevel - 1;
                    changeLevel = changeLevel + CokePrice;
                    return true;
                }
                else if ((payment - CokePrice > 0) && (payment - CokePrice < changeLevel))
                {
                    action = 0;
                    inventoryLevel = inventoryLevel - 1;
                    changeLevel = changeLevel + CokePrice;
                    change = displayMoney(payment - CokePrice);
                    return true;
                }
                else if (inventoryLevel < 1)
                {
                    action = 1;
                    return false;
                }
                else return false;
            }
            else if (changeLevel >= maxChangeCapacity)
            {
                action = 5;
                return false;
            }
            else return false;
        }

        int getInventoryLevel()
        {
            return inventoryLevel;
        }

        int getMaxInventoryCapacity()
        {
            return maxInventoryCapacity;
        }

        bool incrementInventory(int amountToAdd)
        {
            if (inventoryLevel + amountToAdd <= maxInventoryCapacity)
            {
                inventoryLevel = inventoryLevel + amountToAdd;
                return true;
            }
            else
            {
                inventoryLevel = inventoryLevel + 0;
                return false;
            }
        }

        std::string getChangeLevel()
        {
            std:: string result;
            result = displayMoney(changeLevel);
            return result;
        }

        bool incrementChangeLevel(int amountToAdd)
        {
            if (changeLevel + amountToAdd <= maxChangeCapacity)
            {
                changeLevel = changeLevel + amountToAdd;
                return true;
            }
            else
            {
                changeLevel = changeLevel + 0;
                return false;
            }
        }

        std::string getMaxChangeCapacity()
        {
            std:: string result;
            result = displayMoney(maxChangeCapacity);
            return result;

        }

        std::string getCokePrice()
        {
            std:: string result;
            result = displayMoney(CokePrice);
            return result;
        }

        std::string displayMoney(int amount)
        {
            std:: string dollars, cents, result;
            dollars = to_string(amount / 100);
            cents = to_string(amount % 100);
            result = "$" + dollars + "." + (cents.size() == 1 ? "0" : "") + cents;
            return result;
        }
    private:
        std::string machineName;
        int CokePrice;
        int changeLevel;
        int inventoryLevel;
        int maxChangeCapacity = 5000;
        int maxInventoryCapacity = 100;
};
