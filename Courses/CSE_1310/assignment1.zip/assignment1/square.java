public class square
{
    public static void main(String[] args)
    {
       double side_length = 10.0;
       double square_area = side_length * side_length;
       System.out.println(square_area);
    }
}