public class triangle {

    
    public static void main(String[] args) {
        float base = 3;
        float height = 5;
        float area = (base * height)/ 2;
        System.out.println(area);
    }
    
}
