
public class rectangle {

    public static void main(String[] args) {
       double length = 5.5;
       double width = 4;
       double area = length * width;
       double perimeter = 2 * (length + width);
       System.out.println(area);
       System.out.println(perimeter);
    }
    
}
