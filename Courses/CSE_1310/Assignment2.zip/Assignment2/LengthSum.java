import java.util.Scanner;
public class LengthSum {

    
    public static void main(String[] args) {
        System.out.printf("Please enter the first string: ");
        Scanner str = new Scanner(System.in);
        String a = str.nextLine();
        System.out.printf("Please enter the second string: ");
        String b = str.nextLine();
        int c = a.length() + b.length();
        System.out.printf("The first string has length: %d \n", a.length());
        System.out.printf("The second string has length: %d \n", b.length());
        System.out.printf("The sum of the two lengths is: %d", c);
        
    }
    
}
