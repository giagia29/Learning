public class months_no_arrays
{
  public static void main(String[] args) 
  {
    String month1_name = "January";
    String month2_name = "February";
    String month3_name = "March";
    String month4_name = "April";
    String month5_name = "May";
    String month6_name = "June";
    String month7_name = "July";
    String month8_name = "August";
    String month9_name = "September";
    String month10_name = "October";
    String month11_name = "November";
    String month12_name = "December";
    
    int month1_length = 31;
    int month2_length = 28;
    int month3_length = 31;
    int month4_length = 30;
    int month5_length = 31;
    int month6_length = 30;
    int month7_length = 31;
    int month8_length = 31;
    int month9_length = 30;
    int month10_length = 31;
    int month11_length = 30;
    int month12_length = 31;
    
    System.out.printf("%s has %d days.\n", month1_name, month1_length);
    System.out.printf("%s has %d days.\n", month2_name, month2_length);
    System.out.printf("%s has %d days.\n", month3_name, month3_length);
    System.out.printf("%s has %d days.\n", month4_name, month4_length);
    System.out.printf("%s has %d days.\n", month5_name, month5_length);
    System.out.printf("%s has %d days.\n", month6_name, month6_length);
    System.out.printf("%s has %d days.\n", month7_name, month7_length);
    System.out.printf("%s has %d days.\n", month8_name, month8_length);
    System.out.printf("%s has %d days.\n", month9_name, month9_length);
    System.out.printf("%s has %d days.\n", month10_name, month10_length);
    System.out.printf("%s has %d days.\n", month11_name, month11_length);
    System.out.printf("%s has %d days.\n", month12_name, month12_length);

  }
}