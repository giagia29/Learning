import java.util.Scanner;

public class read_n_numbers3
{
  public static int[] user_integers()
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter N: ");
    int N = in.nextInt();
    
    int[] result = new int[N];
    for (int i = 0; i < N; i++)
    {
      System.out.printf("Enter value %d: ", i);
      result[i] = in.nextInt();
    }

    return result;
  }

  public static int find_min(int[] values)
  {
    int result = values[0];
    for (int i = 0; i < values.length; i++)
    {
      if (values[i] < result)
      {
        result = values[i];
      }
    }
    return result;
  }
  
  public static int find_max(int[] values)
  {
    int result = values[0];
    for (int i = 0; i < values.length; i++)
    {
      if (values[i] > result)
      {
        result = values[i];
      }
    }
    return result;
  }
  
public static void main(String[] args) 
{
  int[] numbers = user_integers();
  int smallest = find_min(numbers);
  int largest = find_max(numbers);
  System.out.printf("\n");
  for (int i = 0; i < numbers.length; i++)
  {
    System.out.printf("numbers[%d] = %d", i, numbers[i]);
    if (numbers[i] == smallest)
    {
      System.out.printf(" *** smallest value ***\n");
    }
    else if (numbers[i] == largest)
    {
      System.out.printf(" *** largest value ***\n");
    }
    else
    {
      System.out.printf("\n");
    }
  }
}
}  
