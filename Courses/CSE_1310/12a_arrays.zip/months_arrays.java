public class months_arrays {
  public static void main(String[] args) {
    String[] month_names = {"January", "February", "March",
                            "April", "May", "June",
                            "July", "August", "September",
                            "October", "November", "December"};
    
    int[] month_lengths = {31, 28, 31, 30, 31, 30,
                           31, 31, 30, 31, 30, 31};

    for (int i = 0; i < 12; i++)
    {                                           
//      System.out.printf("%s has %d days.\n",
//                        month_names[i], month_lengths[i]);
      System.out.printf("There are %d days in %s.\n",
                        month_lengths[i], month_names[i]);
    }
  }
}
