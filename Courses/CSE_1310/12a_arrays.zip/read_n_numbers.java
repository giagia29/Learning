import java.util.Scanner;

public class read_n_numbers
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter N: ");
    int N = in.nextInt();
    
    int[] numbers = new int[N];
    for (int i = 0; i < N; i++)
    {
      System.out.printf("Enter value %d: ", i);
      numbers[i] = in.nextInt();
    }

    System.out.printf("\n");
    for (int i = 0; i < N; i++)
    {
      System.out.printf("numbers[%d] = %d\n", i, numbers[i]);
    }
  }
}  
