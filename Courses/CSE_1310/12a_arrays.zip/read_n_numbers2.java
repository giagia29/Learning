import java.util.Scanner;

public class read_n_numbers2
{
  public static int[] user_integers()
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter N: ");
    int N = in.nextInt();
    
    int[] result = new int[N];
    for (int i = 0; i < N; i++)
    {
      System.out.printf("Enter value %d: ", i);
      result[i] = in.nextInt();
    }

    return result;
  }
  
  public static void main(String[] args) 
  {
    int [] numbers = user_integers();
    
    System.out.printf("\n");
    for (int i = 0; i < numbers.length; i++)
    {
      System.out.printf("numbers[%d] = %d\n", i, numbers[i]);
    }
  }
}  
