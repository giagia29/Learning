import java.util.Scanner;
import java.util.ArrayList;

public class read_n_numbers_array_list2
{
  public static ArrayList<Integer> user_integers()
  {
    Scanner in = new Scanner(System.in);
    ArrayList<Integer> result = new ArrayList<Integer>();

    while(true)
    {
      System.out.printf("Enter a number, or q to quit: ");
      String input = in.next();
      if (input.equals("q"))
      {
        return result;
      }
      int number = Integer.parseInt(input);
      result.add(number);
    }
  }

  public static void main(String[] args) 
  {
    ArrayList<Integer> numbers = user_integers();

    System.out.printf("\n");
    for (int i = 0; i < numbers.size(); i++)
    {
      System.out.printf("position %d: = %d\n", i, numbers.get(i));
    }
  }
}  
